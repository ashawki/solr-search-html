#include <iostream.h>

/**
    Purpose: Hello world exemple

    @author Hong-Thai Nguyen
    @version 1.0 9/02/07
*/

main()
{
    cout << "Hello World!";
    return 0;
}